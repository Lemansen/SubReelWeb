"use client";

import { useState } from "react";
import {
  Flame,
  X,
  Settings,
  Compass,
  Home as HomeIcon,
  Layers,
  FolderOpen,
  Calendar,
  User,
  ChevronRight,
  Info,
  Cpu,
  Gauge,
  Gamepad2,
  Monitor,
  RefreshCw,
  Rocket,
} from "lucide-react";

export default function Launcher() {
  const [isNewsOpen, setIsNewsOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [progress, setProgress] = useState(0);
  const [loadingText, setLoadingText] = useState("Проверка файлов...");
  const [isReady, setIsReady] = useState(false);
  const [activeTab, setActiveTab] = useState("main");

  // Состояния конфигурации в окне настроек
  const [allocatedRam, setAllocatedRam] = useState(4);
  const [isFullScreen, setIsFullScreen] = useState(false);
  const [isAutoUpdate, setIsAutoUpdate] = useState(true);
  const [closeOnLaunch, setCloseOnLaunch] = useState(true);
  const [activeSettingsTab, setActiveSettingsTab] = useState("performance");

  const handlePlayClick = () => {
    if (isPlaying || isReady) return;

    setIsPlaying(true);
    setProgress(0);
    setLoadingText("Проверка файлов...");

    const interval = setInterval(() => {
      setProgress((prev) => {
        const next = prev + Math.floor(Math.random() * 8) + 2;
        if (next >= 100) {
          clearInterval(interval);
          setLoadingText("Готово!");
          setIsReady(true);
          return 100;
        }
        return next;
      });
    }, 200);
  };

  // Исходные данные новостей
  const newsData = [
    {
      id: 1,
      category: "Лаунчер",
      title: "SubReelLauncher 1.0",
      version: "v3.0.0-release",
      date: "Сегодня в 14:20",
      author: "Lemansen",
      patchnotes: [
        { title: "Полноценная оптимизация FPS", desc: "Переработан движок рендеринга чанков. Стабильный прирост кадров на видеокартах серий GTX/RTX составляет до 25% за счет оптимизации памяти Java." },
        { title: "Новая сюжетная линия квестов", desc: "Добавлена цепочка из 40 стартовых заданий в главном хабе. Награды автоматически синхронизируются с вашим личным кабинетом." },
        { title: "Критические баги и исправления", desc: "Полностью решена проблема дублирования предметов при закрытии беспроводного терминала хранения. Обновлен сетевой протокол защиты." },
      ],
    },
    {
      id: 2,
      category: "Сервер",
      title: "Технические работы на TechnoMagic",
      version: "v1.4.2-server",
      date: "Вчера в 04:00",
      author: "TechTeam",
      patchnotes: [
        { title: "Обновление серверного ядра", desc: "Исправлены утечки памяти при высокой нагрузке онлайн-игроков. Лимит чанков на команду увеличен." },
        { title: "Глобальный баланс мобов", desc: "Ночные монстры стали сильнее на 15%, но шанс выпадения редких эссенций увеличен вдвое. Добавлен новый мини-босс на спавне." },
      ],
    },
    {
      id: 3,
      category: "Сервер",
      title: "Патч безопасности прокси",
      version: "v1.0.3-hotfix",
      date: "28.06.2026",
      author: "Lemansen",
      patchnotes: [
        { title: "Фикс DDoS-уязвимости", desc: "Заблокирован эксплойт с поддельной авторизацией пакетов сессии. Защита BungeeCord обновлена." },
      ],
    },
    {
      id: 4,
      category: "Сайт",
      title: "Обновление личного кабинета",
      version: "v2.1.0-web",
      date: "25.06.2026",
      author: "WebDev",
      patchnotes: [
        { title: "Интеграция платежной системы", desc: "Добавлены новые методы пополнения баланса без комиссии." },
        { title: "Реализация скинов высокого разрешения", desc: "Теперь вы можете загружать HD-скины и плащи размером до 1024x512 пикселей." },
      ],
    },
  ];

  const categories = ["Все", "Сервер", "Лаунчер", "Сайт"];
  const [selectedCategory, setSelectedCategory] = useState("Все");
  const [currentNewsIndex, setCurrentNewsIndex] = useState(0);

  const filteredNews = newsData.filter(
    (item) => selectedCategory === "Все" || item.category === selectedCategory
  );
  const currentNews = filteredNews[currentNewsIndex] || null;

  const handleCategoryChange = (cat: string) => {
    setSelectedCategory(cat);
    setCurrentNewsIndex(0);
  };

  const handlePrevNews = () => {
    if (filteredNews.length <= 1) return;
    setCurrentNewsIndex((prev) => (prev === 0 ? filteredNews.length - 1 : prev - 1));
  };

  const handleNextNews = () => {
    if (filteredNews.length <= 1) return;
    setCurrentNewsIndex((prev) => (prev === filteredNews.length - 1 ? 0 : prev + 1));
  };

  // === КОНФИГУРАЦИЯ ЭКРАНА НАСТРОЕК ===
  const settingsCategories = [
    {
      id: "performance",
      label: "Производительность",
      hint: "Java и память",
      icon: Cpu,
      title: "Системные параметры",
      desc: "Конфигурация выделения ресурсов под клиент игры.",
      items: [
        {
          id: "ram",
          type: "slider" as const,
          icon: Gauge,
          label: "Выделение оперативной памяти",
          desc: "Рекомендуется выделять не менее половины доступного объема вашей оперативной памяти.",
          value: allocatedRam,
          min: 2,
          max: 16,
          onChange: setAllocatedRam,
        },
      ],
    },
    {
      id: "game",
      label: "Игра и лаунчер",
      hint: "Запуск и обновления",
      icon: Gamepad2,
      title: "Параметры запуска",
      desc: "Поведение лаунчера и клиента игры при старте.",
      items: [
        {
          id: "fullscreen",
          type: "toggle" as const,
          icon: Monitor,
          label: "Запускать в полноэкранном режиме",
          desc: "Игра автоматически развернется на весь экран сразу после запуска клиента.",
          value: isFullScreen,
          onChange: setIsFullScreen,
        },
        {
          id: "autoupdate",
          type: "toggle" as const,
          icon: RefreshCw,
          label: "Автоматическое обновление файлов",
          desc: "Лаунчер будет автоматически сверять хеш-суммы файлов перед каждым стартом.",
          value: isAutoUpdate,
          onChange: setIsAutoUpdate,
        },
        {
          id: "closeonlaunch",
          type: "toggle" as const,
          icon: Rocket,
          label: "Закрывать лаунчер после запуска",
          desc: "Окно лаунчера будет автоматически скрываться сразу после старта игры.",
          value: closeOnLaunch,
          onChange: setCloseOnLaunch,
        },
      ],
    },
  ];

  const activeCategoryData =
    settingsCategories.find((c) => c.id === activeSettingsTab) || settingsCategories[0];

  return (
    <main className="launcher-container">
      <div className="app-shell">
        {/* === TOP: NAVBAR === */}
        <header className={`navbar ${isNewsOpen || isSettingsOpen ? "news-active" : ""}`}>
          <div className="logo-zone">
            <span className="logo-icon">S</span>
            <div>
              <h3>SubReel</h3>
              <p>v0.1.0</p>
            </div>
          </div>

          <nav className="nav-links">
            <button
              className={activeTab === "main" && !isSettingsOpen ? "active" : ""}
              onClick={() => { setActiveTab("main"); setIsSettingsOpen(false); }}
            >
              <HomeIcon size={16} /> Главная
            </button>
            <button
              className={activeTab === "community" && !isSettingsOpen ? "active" : ""}
              onClick={() => { setActiveTab("community"); setIsSettingsOpen(false); }}
            >
              <Compass size={16} /> Сообщество
            </button>
            <button
              className={isSettingsOpen ? "active" : ""}
              onClick={() => setIsSettingsOpen(true)}
            >
              <Settings size={16} /> Настройки
            </button>
          </nav>

          <div className="user-profile">
            <div className="avatar">LM</div>
            <span>Lemansen</span>
          </div>
        </header>

        {/* === CENTER: MAIN CONTENT === */}
        <main className="content">
          {activeTab === "main" ? (
            <>
              <button className="news-chip" onClick={() => setIsNewsOpen(true)}>
                <Flame size={16} className="fire-icon" />
                <span>Свежие новости проекта</span>
              </button>

              <div className="center-hero">
                <h1>Survival Reborn</h1>
                <p>Добро пожаловать на обновленный технологичный клиент SubReel.</p>
              </div>
            </>
          ) : (
            <div className="center-hero">
              <h1>Сообщество</h1>
              <p>Раздел в разработке.</p>
            </div>
          )}
        </main>

        {/* === BOTTOM: FOOTER PANEL === */}
        <footer className={`bottom-bar ${isNewsOpen || isSettingsOpen ? "news-active" : ""}`}>
          <div className="bottom-left">
            <button className="secondary-btn custom-btn-1">
              <Layers size={16} />
              <span>Создать сборку</span>
            </button>
            <button className="secondary-btn custom-btn-2">
              <FolderOpen size={16} />
              <span>Выбрать версию</span>
            </button>
          </div>

          <div className={`bottom-right ${isPlaying ? "active" : ""}`}>
            <div className="progress-wrapper">
              <div className="progress-info">
                <span>{loadingText}</span>
                <span>{progress}%</span>
              </div>
              <div className="bar">
                <div className="fill" style={{ width: `${progress}%` }}></div>
              </div>
            </div>

            <button
              className={`play-btn ${isPlaying && !isReady ? "loading-state" : ""} ${isReady ? "ready-state" : ""}`}
              onClick={handlePlayClick}
            >
              {isReady ? "ЗАПУСК" : isPlaying ? "ЗАГРУЗКА..." : "ИГРАТЬ"}
            </button>
          </div>
        </footer>

        {/* === FULLSCREEN NEWS OVERLAY === */}
        <div className={`news-panel ${isNewsOpen ? "open" : ""}`}>
          <button className="close-btn" onClick={() => setIsNewsOpen(false)}>
            <X size={24} />
          </button>

          <div className="news-layout">
            <div className="news-meta-side">
              {currentNews ? (
                <>
                  <div className="news-badge">{currentNews.category}</div>
                  <div className="news-title-block">
                    <h1>{currentNews.title}</h1>
                    <div className="news-version">Версия: <span>{currentNews.version}</span></div>
                  </div>
                  <div className="news-details">
                    <div className="detail-item">
                      <Calendar size={16} />
                      <span>{currentNews.date}</span>
                    </div>
                    <div className="detail-item">
                      <User size={16} />
                      <span>Разработчик: <strong>{currentNews.author}</strong></span>
                    </div>
                  </div>
                </>
              ) : (
                <div className="empty-news-state">В этой категории пока нет новостей.</div>
              )}

              <div className="news-tabs-container">
                <h4>Категории новостей</h4>
                <div className="news-categories-grid">
                  {categories.map((cat) => (
                    <button
                      key={cat}
                      className={`category-tab-btn ${selectedCategory === cat ? "active" : ""}`}
                      onClick={() => handleCategoryChange(cat)}
                    >
                      {cat}
                    </button>
                  ))}
                </div>

                {filteredNews.length > 0 && (
                  <div className="news-slider-controls">
                    <button className="slider-arrow-btn" onClick={handlePrevNews} disabled={filteredNews.length <= 1}>←</button>
                    <span className="slider-counter">{currentNewsIndex + 1} из {filteredNews.length}</span>
                    <button className="slider-arrow-btn" onClick={handleNextNews} disabled={filteredNews.length <= 1}>→</button>
                  </div>
                )}
              </div>
            </div>

            <div className="news-body-side">
              <div className="patch-header">
                <h2>Патчноут изменений</h2>
                <p>Список исправлений, нововведений и оптимизаций сборки.</p>
              </div>

              <div className="patch-scroll-area">
                {currentNews && currentNews.patchnotes.length > 0 ? (
                  <ul className="changelog-list">
                    {currentNews.patchnotes.map((note, index) => (
                      <li key={index}>
                        <h4>{note.title}</h4>
                        <p>{note.desc}</p>
                      </li>
                    ))}
                  </ul>
                ) : (
                  <div className="no-changes-text">Для данного события список изменений пуст или не требуется.</div>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* === FULLSCREEN SETTINGS OVERLAY (переработанный дизайн) === */}
        <div className={`news-panel ${isSettingsOpen ? "open" : ""}`}>
          <button className="close-btn" onClick={() => setIsSettingsOpen(false)}>
            <X size={24} />
          </button>

          <div className="settings-layout">
            
            {/* ЛЕВАЯ КОЛОНКА: заголовок + навигация по разделам */}
            <aside className="settings-sidebar">
              <div className="news-badge">Конфигурация</div>
              <div className="news-title-block">
                <h1>Настройки</h1>
                <div className="news-version">Параметры лаунчера и Java</div>
              </div>

              <nav className="settings-nav-list">
                {settingsCategories.map((cat) => {
                  const Icon = cat.icon;
                  return (
                    <button
                      key={cat.id}
                      className={`settings-nav-item ${activeSettingsTab === cat.id ? "active" : ""}`}
                      onClick={() => setActiveSettingsTab(cat.id)}
                    >
                      <Icon size={18} />
                      <span className="settings-nav-text">
                        <span className="settings-nav-title">{cat.label}</span>
                        <span className="settings-nav-hint">{cat.hint}</span>
                      </span>
                      <ChevronRight size={16} className="settings-nav-chevron" />
                    </button>
                  );
                })}
              </nav>

              <div className="news-details settings-savebar">
                <div className="detail-item">
                  <Info size={16} />
                  <span>Изменения сохраняются автоматически.</span>
                </div>
              </div>
            </aside>

            {/* ПРАВАЯ КОЛОНКА: карточки настроек активного раздела */}
            <div className="settings-content">
              <div className="patch-header">
                <h2>{activeCategoryData.title}</h2>
                <p>{activeCategoryData.desc}</p>
              </div>

              <div className="patch-scroll-area">
                <div className="settings-card-list">
                  {activeCategoryData.items.map((item) => {
                    const Icon = item.icon;
                    const pct =
                      item.type === "slider"
                        ? ((item.value as number) - item.min!) / (item.max! - item.min!) * 100
                        : 0;

                    return (
                      <div className="settings-card" key={item.id}>
                        <div className="settings-card-icon">
                          <Icon size={18} />
                        </div>
                        <div className="settings-card-main">
                          <div className="settings-card-head">
                            <h4>{item.label}</h4>
                            {item.type === "toggle" ? (
                              <button
                                type="button"
                                role="switch"
                                aria-checked={item.value as boolean}
                                className={`toggle-switch ${item.value ? "on" : ""}`}
                                onClick={() => (item.onChange as (v: boolean) => void)(!item.value)}
                              >
                                <span className="toggle-knob" />
                              </button>
                            ) : (
                              <span className="settings-value-pill">{item.value} ГБ</span>
                            )}
                          </div>
                          <p>{item.desc}</p>

                          {item.type === "slider" && (
                            <div className="ram-slider-block">
                              <input
                                type="range"
                                min={item.min}
                                max={item.max}
                                step={1}
                                value={item.value as number}
                                onChange={(e) => (item.onChange as (v: number) => void)(Number(e.target.value))}
                                className="ram-slider"
                                style={{
                                  background: `linear-gradient(to right, #4C85FF 0%, #78C8FF ${pct}%, rgba(255,255,255,0.08) ${pct}%, rgba(255,255,255,0.08) 100%)`,
                                }}
                              />
                              <div className="ram-slider-ticks">
                                <span>{item.min} ГБ</span>
                                <span className="ram-slider-rec">рекомендовано 8 ГБ</span>
                                <span>{item.max} ГБ</span>
                              </div>
                            </div>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </main>
  );
}