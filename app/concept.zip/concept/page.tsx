"use client";

import { useState } from "react";
import {
  Flame,
  X,
  Settings,
  Compass,
  Home as HomeIcon,
  Layers,
  FolderOpen,
  Minus,
  Square,
  User, // Добавили иконку для заглушки аккаунта, если понадобится
} from "lucide-react";
import NewsPanel from "./components/NewsPanel";
import SettingsOverlay from "./components/SettingsOverlay";

// Если у вас будет отдельный компонент для аккаунта, импортируйте его сюда:
// import AccountOverlay from "./components/AccountOverlay";

export default function Launcher() {
  // === Состояния экранов и вкладок ===
  // Расширяем overlay-состояние для поддержки "account"
  const [activeOverlay, setActiveOverlay] = useState<"none" | "news" | "settings" | "account">("none");
  const [activeTab, setActiveTab] = useState<"main" | "community">("main");

  // Состояния игрового процесса
  const [isPlaying, setIsPlaying] = useState(false);
  const [progress, setProgress] = useState(0);
  const [loadingText, setLoadingText] = useState("Проверка файлов...");
  const [isReady, setIsReady] = useState(false);

  // Состояния конфигурации
  const [allocatedRam, setAllocatedRam] = useState(4);
  const [isFullScreen, setIsFullScreen] = useState(false);
  const [isAutoUpdate, setIsAutoUpdate] = useState(true);
  const [closeOnLaunch, setCloseOnLaunch] = useState(true);

  // === Логика управления оконным режимом ===
  const toggleFullscreen = async () => {
    if (!document.fullscreenElement) {
      await document.documentElement.requestFullscreen();
    } else {
      await document.exitFullscreen();
    }
  };

  const closeLauncher = () => {
    window.location.href = "/";
  };

  // Общий компонент оконных кнопок
  const WindowControls = () => (
    <div className="window-controls">
      <button className="window-btn" title="Свернуть (Компактный режим)">
        <Minus size={14} />
      </button>
      <button className="window-btn" onClick={toggleFullscreen} title="Развернуть на весь экран">
        <Square size={11} />
      </button>
      <button className="window-btn close" onClick={closeLauncher} title="Закрыть">
        <X size={14} />
      </button>
    </div>
  );

  const handlePlayClick = () => {
    if (isPlaying || isReady) return;

    setIsPlaying(true);
    setProgress(0);
    setLoadingText("Проверка файлов...");

    const interval = setInterval(() => {
      setProgress((prev) => {
        const next = prev + Math.floor(Math.random() * 8) + 2;
        if (next >= 100) {
          clearInterval(interval);
          setLoadingText("Готово!");
          setIsReady(true);
          return 100;
        }
        return next;
      });
    }, 200);
  };

  return (
    <main className="launcher-container">
      <div className="app-shell">
        
        {/* === ОСНОВНОЙ ВЕРХНИЙ НАВБАР === */}
        <header className={`navbar ${activeOverlay !== "none" ? "displaced-top" : ""}`}>
          <div className="logo-zone">
            <span className="logo-icon">S</span>
            <div>
              <h3>SubReel</h3>
              <p>v0.1.0</p>
            </div>
          </div>

          <nav className="nav-links">
            <button
              className={activeTab === "main" && activeOverlay === "none" ? "active" : ""}
              onClick={() => { setActiveTab("main"); setActiveOverlay("none"); }}
            >
              <HomeIcon size={16} /> Главная
            </button>
            <button
              className={activeTab === "community" && activeOverlay === "none" ? "active" : ""}
              onClick={() => { setActiveTab("community"); setActiveOverlay("none"); }}
            >
              <Compass size={16} /> Сообщество
            </button>
            <button
              className={activeOverlay === "settings" ? "active" : ""}
              onClick={() => setActiveOverlay("settings")}
            >
              <Settings size={16} /> Настройки
            </button>
          </nav>

          <div className="header-right-zone">
            {/* Превратили блок профиля в интерактивную кнопку активации вкладки Аккаунт */}
            <button 
              className={`user-profile-btn ${activeOverlay === "account" ? "active" : ""}`}
              onClick={() => setActiveOverlay("account")}
              title="Личный кабинет"
            >
              <div className="avatar">LM</div>
              <span>Lemansen</span>
            </button>
            <WindowControls />
          </div>
        </header>

        {/* === ЦЕНТРАЛЬНЫЙ ОСНОВНОЙ КОНТЕНТ === */}
        <main className={`content ${activeOverlay !== "none" ? "fade-out-content" : ""}`}>
          {activeTab === "main" ? (
            <div className="tab-wrapper">
              <button className="news-chip" onClick={() => setActiveOverlay("news")}>
                <Flame size={16} className="fire-icon" />
                <span>Свежие новости проекта</span>
              </button>

              <div className="center-hero">
                <h1>Survival Reborn</h1>
                <p>Добро пожаловать на обновленный технологичный клиент SubReel.</p>
              </div>
            </div>
          ) : (
            <div className="center-hero">
              <h1>Сообщество</h1>
              <p>Раздел в разработке.</p>
            </div>
          )}
        </main>

        {/* === ОСНОВНОЙ НИЖНИЙ ПОДВАЛ === */}
        <footer className={`bottom-bar ${activeOverlay !== "none" ? "displaced-bottom" : ""}`}>
          <div className="bottom-left">
            <button className="secondary-btn custom-btn-1">
              <Layers size={16} />
              <span>Создать сборку</span>
            </button>
            <button className="secondary-btn custom-btn-2">
              <FolderOpen size={16} />
              <span>Выбрать версию</span>
            </button>
          </div>

          <div className={`bottom-right ${isPlaying ? "active" : ""}`}>
            <div className="progress-wrapper">
              <div className="progress-info">
                <span>{loadingText}</span>
                <span>{progress}%</span>
              </div>
              <div className="bar">
                <div className="fill" style={{ width: `${progress}%` }}></div>
              </div>
            </div>

            <button
              className={`play-btn ${isPlaying && !isReady ? "loading-state" : ""} ${isReady ? "ready-state" : ""}`}
              onClick={handlePlayClick}
            >
              {isReady ? "ЗАПУСК" : isPlaying ? "ЗАГРУЗКА..." : "ИГРАТЬ"}
            </button>
          </div>
        </footer>

        {/* === ДОЧЕРНИЙ КОМПОНЕНТ НАСТРОЕК === */}
        <SettingsOverlay
          isOpen={activeOverlay === "settings"}
          onCloseSettings={() => setActiveOverlay("none")}
          onTabChange={(tab) => setActiveTab(tab)}
          allocatedRam={allocatedRam}
          setAllocatedRam={setAllocatedRam}
          isFullScreen={isFullScreen}
          setIsFullScreen={setIsFullScreen}
          isAutoUpdate={isAutoUpdate}
          setIsAutoUpdate={setIsAutoUpdate}
          closeOnLaunch={closeOnLaunch}
          setCloseOnLaunch={setCloseOnLaunch}
          WindowControls={WindowControls}
        />

        {/* === ДОЧЕРНИЙ КОМПОНЕНТ НОВОСТЕЙ === */}
        <NewsPanel
          isOpen={activeOverlay === "news"}
          onClose={() => setActiveOverlay("none")}
        />

        {/* === ОВЕРЛЕЙ / ВКЛАДКА АККАУНТА === */}
        {/* Вы можете вынести этот JSX в отдельный файл AccountOverlay.tsx по аналогии с настройками */}
        <div className={`settings-overlay-panel ${activeOverlay === "account" ? "open" : ""}`}>
          <header className="settings-internal-navbar">
            <div className="logo-zone">
              <span className="logo-icon settings-mode">S</span>
              <div>
                <h3>SubReel</h3>
                <p className="orange-text">Личный кабинет</p>
              </div>
            </div>

            <nav className="nav-links">
              <button onClick={() => { setActiveOverlay("none"); setActiveTab("main"); }}>
                Главная
              </button>
              <button onClick={() => { setActiveOverlay("none"); setActiveTab("community"); }}>
                Сообщество
              </button>
              <button onClick={() => setActiveOverlay("settings")}>
                Настройки
              </button>
            </nav>

            <div className="header-right-zone">
              <div className="user-profile active-profile">
                <div className="avatar">LM</div>
                <span>Lemansen</span>
              </div>
              <WindowControls />
            </div>
          </header>

          <div className="settings-layout-wrapper">
            <div className="settings-layout">
              <aside className="settings-sidebar">
                <div className="news-badge">Профиль</div>
                <div className="news-title-block">
                  <h1>Аккаунт</h1>
                  <div className="news-version">Управление подпиской и скином</div>
                </div>
                <div className="news-details settings-savebar" style={{ marginTop: "auto" }}>
                  <button 
                    className="secondary-btn" 
                    style={{ width: "100%", justifyContent: "center", background: "rgba(255, 76, 76, 0.1)", color: "#ff4c4c" }}
                    onClick={() => setActiveOverlay("none")}
                  >
                    Выйти из системы
                  </button>
                </div>
              </aside>

              <div className="settings-content">
                <div className="patch-header">
                  <h2>Добро пожаловать back, Lemansen</h2>
                  <p>Здесь будут отображаться статус персонажа, управление скином и плащом.</p>
                </div>
                <div className="patch-scroll-area">
                  <div className="settings-card-list">
                    <div className="settings-card">
                      <div className="settings-card-main">
                        <h4>Статус авторизации</h4>
                        <p style={{ marginTop: "4px", opacity: 0.7 }}>Сессия активна. Защита игрового аккаунта работает в штатном режиме.</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

      </div>
    </main>
  );
}